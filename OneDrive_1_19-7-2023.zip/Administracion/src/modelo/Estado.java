package modelo;

public enum Estado {

	Nuevo, EnTremite, Anulado, Eliminado, Archivado
}
