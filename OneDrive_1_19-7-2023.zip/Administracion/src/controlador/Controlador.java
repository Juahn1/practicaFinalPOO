package controlador;

import java.util.List;

import modelo.Edificio;
import modelo.Estado;
import modelo.Persona;
import modelo.Reclamo;
import modelo.Unidad;

public class Controlador {

	private List<Unidad> unidades;
	private List<Persona> personas;
	private List<Edificio> edificios;
	private List<Reclamo> reclamos;
	
	public void transferirUnidad(int codigo, String piso, String numero, String documento) {
		Unidad unidad = buscarUnidad(codigo, piso, numero);
		Persona persona = buscarPersona(documento);
		unidad.transferir(persona);
	}

	public void agregarDuenioUnidad(int codigo, String piso, String numero, String documento) {
		Unidad unidad = buscarUnidad(codigo, piso, numero);
		Persona persona = buscarPersona(documento);
		unidad.agregarDuenio(persona);
	}

	public void alquilarUnidad(int codigo, String piso, String numero, String documento) {
		Unidad unidad = buscarUnidad(codigo, piso, numero);
		Persona persona = buscarPersona(documento);
		unidad.alquilar(persona);
	}

	public void agregarInquilinoUnidad(int codigo, String piso, String numero, String documento) {
		Unidad unidad = buscarUnidad(codigo, piso, numero);
		Persona persona = buscarPersona(documento);
		unidad.agregarInquilino(persona);
	}

	public void liberarUnidad(int codigo, String piso, String numero) {
		Unidad unidad = buscarUnidad(codigo, piso, numero);
		unidad.liberar();
	}
	
	public void habitarUnidad(int codigo, String piso, String numero) {
		Unidad unidad = buscarUnidad(codigo, piso, numero);
		unidad.habitar();;
	}
	
	public void agregarPersona(String documento, String nombre) {
		Persona persona = new Persona(documento, nombre);
		personas.add(persona);
	}
	
	public void eliminarPersona(String documento) {
		Persona persona = buscarPersona(documento);
		personas.remove(persona);
	}
	
	public int agregarReclamo(int codigo, String piso, String numero, String documento, String ubicacion, String descripcion) {
		Edificio edificio = buscarEdificio(codigo);
		Unidad unidad = buscarUnidad(codigo, piso, numero);
		Persona persona = buscarPersona(documento);
		Reclamo reclamo = new Reclamo(persona, edificio, ubicacion, descripcion, unidad);
		reclamos.add(reclamo);
		return reclamo.getNumero();
	}
	
	public void agregarImagenAReclamo(int numero, String direccion, String tipo) {
		Reclamo reclamo = buscarReclamo(numero);
		reclamo.agregarImagen(direccion, tipo);
	}
	
	public void cambiarEstado(int numero, Estado estado) {
		Reclamo reclamo = buscarReclamo(numero);
		reclamo.cambiarEstado(estado);
	}
	
	private Edificio buscarEdificio(int codigo){
		for(Edificio edificio : edificios)
			if(edificio.soyElEdificio(codigo))
				return edificio;
		return null;
	}

	private Unidad buscarUnidad(int codigo, String piso, String numero) {
		for(Unidad unidad : unidades)
			if(unidad.soyLaUnidad(codigo, piso, numero))
				return unidad;
		return null;
	}	
	
	private Persona buscarPersona(String documento)  {
		for(Persona persona : personas)
			if(persona.soyLaPersona(documento))
				return persona;
		return null;
	}
	
	private Reclamo buscarReclamo(int numero) {
		for(Reclamo reclamo : reclamos)
			if(reclamo.soyElReclamo(numero))
				return reclamo;
		return null;
	}
}
